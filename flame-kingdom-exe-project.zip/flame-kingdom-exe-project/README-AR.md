# تحويل لعبة Flame Kingdom إلى EXE من الهاتف

هاد المشروع واجد باش GitHub يصاوب ليك نسخة Windows EXE باستعمال خادم Windows سحابي؛ ما محتاجش كمبيوتر.

## الخطوات من الهاتف
1. دخل إلى https://github.com وسجّل الدخول أو أنشئ حساباً.
2. اضغط `+` ثم `New repository`، وسمّيه `flame-kingdom` وخليه `Public` أو `Private` ثم `Create repository`.
3. داخل المستودع اضغط `Add file` ثم `Upload files`.
4. فكّ ضغط ملف ZIP اللي عطاك ChatGPT، ثم ارفع **محتويات** المجلد (ومنها مجلد `.github`). إذا ما بانش `.github` فمدير الملفات، استعمل GitHub من المتصفح بوضع سطح المكتب أو ارفع الملفات عبر GitHub web upload مع التأكد من إضافة `.github/workflows/build.yml`.
5. اضغط `Commit changes` وانتظر حتى يكمّل الرفع.
6. افتح تبويب `Actions` في المستودع. اختار `Build Windows EXE` ثم `Run workflow` إذا ما بدا البناء تلقائياً.
7. افتح عملية البناء الخضراء بعد ما تكمل، وانزل لقسم `Artifacts`.
8. حمّل `Flame-Kingdom-Windows-EXE.zip` وافتحه؛ داخله ملفات `.exe`. ملف Portable يشتغل مباشرة غالباً، والملف الآخر للتثبيت.

ملاحظات:
- البناء كيحتاج اتصال بالإنترنت وحساب GitHub.
- النسخة غير موقّعة بشهادة Windows، لذلك قد يظهر تحذير SmartScreen.
- بعض خصائص اللعبة التي تعتمد على الإنترنت، مثل الخطوط الخارجية، ستحتاج اتصالاً.
